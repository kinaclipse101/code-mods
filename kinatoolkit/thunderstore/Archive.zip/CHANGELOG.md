## 0.1.8
- added r2api as a dep so testscene always gets added back ,.,. (thank you chinchi :plead: ,..,
- updated parsing of run start/debug plains commands to work with arguments in quotations (eg. delay 4 \"spawn_as BrotherBody\" is now valid,.., thank you lordryn :plead: .,. ,

## 0.1.7
- added hallowed concepts interactables .,,.
- added artifact portal ,,,.

## 0.1.6
- i keep accidentally shipping debug builds rahhhhhhhhhhhh made hot reload support proper so shouldnt spam errors in log if i do that agai n.,,.

## 0.1.5
- removed ``disable_interactables`` and ``set_difficulty`` due to debug toolkits ``no_interactables`` and ``set_difficulty`` commands making them obsolete .,,.,.,.

## 0.1.4
- i did an oops and accidentally got rid of the default json config oops should be fixed sorry .,,. 

## 0.1.3
- fixed boss command accidentally only having artifact key (thanks you alice in ss2cord for pointings out to me( ,..,
- made stage start commands run once the players body is spawned .,.,,. should make it so give_money in the default works now .,.,,.

## 0.1.2 
- added a "enter debug plains" button to the pause menu while in a run
- thank you lordryn for reminding me :pleading: .,., 
- added ``set_difficulty`` command which lets you ,.,. set difficulty ,.., mid run .,., 
- added more gifs to readme and made commands look prettier ,., .
- removed a few debug lines i left in because oops ,. 
- removed an accidental extra void item in the base debug plains json ,.,. 
- wrapped json edit loading in a try catch in case anything goes wrong ,.., 

## 0.1.1
- i fucked up the readme fuckkkkkkkkkk ., .

## 0.1.0
- initial release., ,.
