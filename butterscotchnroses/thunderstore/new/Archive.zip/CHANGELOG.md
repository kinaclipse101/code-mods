## 0.3.5
- fixed cooler eclipse pink eclipse chance not working properly ,.., 
- added cooler eclipse only on whitelist stages and disable on hidden realms config ,.,.
- fixed an index out of bounds with who did damage if you killed a boss without dealing damage linked to you (eg tricorn without [equipmentdamagesource](https://thunderstore.io/c/riskofrain2/p/Lordryn/DamageSourceForEquipment/) ,.. thank you for reporting this one gemo :plead: ,.,. 
- fixed zandatsu skillsmas edit causing a type load error ,..

## 0.3.4
- added multipliers for incoming gold and xp and interactable card costs ,., 
- removed loading screen sprite replacements (its in loadingspriteadditions !!!(

## 0.3.3
- added acolyte green soul patch ,., makes her m2 soul ,.., green .,., 
- removed halcyon shrine speed edits as it made issue .,, other mods do same thing so dont feel like fixing :soyheart: , .,
- moved mod to other team,.. ,
- (hopefully) better button recolor blacklist ,.,. ill have to go through and get them properly some time ,.,.
- temporarily changed mod icon .,., its like 4 and i need to sleep but want to change it to be better ,., 

## 0.3.2
- hopefully fixed an issue with whodiddamage causing an nre (couldnt replicate sorry lordryn,. ,.
- added textmeshpro colors to coloredits tab .,, like ones used in logs/ingame/etc ([ror2helper lets you see them well i think,.](https://icebro.party/ror2helper))
- set teamhealthcolor to be disabled by default since it wouldnt do anything if you didnt change any of the configs for it,..,,.
- added cursoredits dropdown menu to select cursor (usually used optiongenerator and forgot to add this one to roo oops .,. thanks lordryn .,.)
- made button recolors recolor more ui elements and have a slightly better blacklist for buttons it shouldnt .,., 
- finally gave it an icon in roo and fixed some other configs not having roo settings ,.., 

## 0.3.1
- added cursor edits ,.,. 
- added loading screen sprite replacements .,., 
- hopefully fixed malachite edit on allied enemies keeping the little x after they died ,. 
- also hopefully fixed crown on who did damage not working right and displaying sometimes on wrong player,. ,. 
- moved old config fixer config into the main bnr section ,.,.

## 0.3.0
- added who did damage (prints damage count for each player after a boss is killed in multiplayer).,,. 
- added color catalog editor .,,. 
- added a 1/200 chance for the loading screen to display random numbers instead of actual loading percent ,. 
- added post processing editor ,. ,.
- added team health color editor ,.,. 
- added ukulele pronouns ,.,.
- added client side config (disables content that would cause desyncs automatically ),.,. .
- mightve broken something hsv skins related um ,.., if i did tell me ,.. .,

## 0.2.1
- now is a release build so shouldnt need unityhotreload to stop constant log spam TT .,,.
- added a try catch to skin recolors so an empty config for it wont cause the game to hang .,,.,
- made skin_clear run on new runs/stages so if you were trying recolor_skin with one skin then went over to another in a different run it wouldnt swap you back .,,.,. 
- fixed an nre when starstorm patches were enabled while indev config was false ,.,. .

## 0.2.0 
- sorrys for such a long wait ,..,.,,. was busy ,..,.,.,
- this update moved a couple configs from "BNR - " to "Mods - " ,.,. check your configs in case you edited anys of those !!
- HSV skin recolors !!!! very cool ,..,., maybe branching into own mod later ,.,.,. want to optimize it a little more so it doesnt take up load times as much !!!
- skillsmas zandatsu recharge on kill patch .,., evil .,,.,
- debugging plains patch to not kick you out everys single time you try to leave !!
- photomode patch to hopefully fix nre on leaving photomode and disable camera movement while console is open .,.
- enemies return patch to give commando judgement a pink alt .,,. 
- reworked icetool patch to apply a debuff before freezing the enemy ,.,. ,.idea from abra escape d!!
- fixed ping colors not changing highlight color ,.,.
- updated allynames config to fix best buddy, operator drones and drone boy not having the correct body name to be renamed .,,. 
- updated cooler eclipse whitelist/blacklist to no longer include golemplains and goldshores twice .,,. 
- fixed cooler eclipse whitelist not working .,.,
- made cooler eclipse networked .,.,.,.
- added a config to update old default configs ,.,. 
- refactored the codebase a little so modded patches should no longer error if the mod isnt present .,,.., 

## 0.1.2
- carving kit model and icons !!!!!!!! thanks you canthi :pleading: .,,.. ,,..,. ,., .,.,., ., 
- hopefullys networked carving kit special material for free shrine and little shrineling !!!!
- updated mod icon !!!!!!!!
- added old drone visibility thing !!!!! little icon above dead drones .,.,.,,. like other drone visibility mod but old and worse code .,.,,. style thing !! 
- added ping recolors !!!!color your pings !!!!!!!!!!!!!!!!!! (wolfoqol friendly ping not supporteds yet <//3 ,.., 

## 0.1.1
- added ally name support !!!!!!! nows able to add any body name ,.,..,.,., sorrys oddbread on github took ac names from your pr to ally names ,..,,..,.,,..,., .,. 
- fixed carving kit disable not owrkings i think !! and added custom material for free shrine of the woods !!!!!!
- networked green portal to blue portal halcyon shrine edit !!!! portal will now appear correctlys for clients ,.., 
- fixed inferno changes doing !! nothing i think ,.., 

## 0.1.0
- releas e!!!
