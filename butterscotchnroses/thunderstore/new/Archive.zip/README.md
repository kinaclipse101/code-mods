# ButterscotchandRosesBaseMod
note !! this is mostly a modpack base mod for myself !!!!! just uploading to thunderstore so im able to share via modpack codes ,,.,. so some things arent done very well ,..,. be warned !!!!!!!!!!!!!! also have not tested this in multiplayer very much so .,.,,. ,., .,,.

everything is configurable to some degree too ,.,,. so if you dont like an edit !! just disable it you freak !!!

### basegame edits ,.,,.
<details>
<summary> cursor edits ,.,.  </summary>

- lets you use random cursors i found in the files ,.,.. and lets you cahnge its color ,.. ,

![](https://files.catbox.moe/wd6fce.png)

![](https://files.catbox.moe/qwkgp7.png)

![](https://files.catbox.moe/71dfho.png)


</details>

<details>
<summary> acolyte gree nsoul ,.,.  </summary>

- makes acolyte soul green ,.., undyne ,.., 

![](https://files.catbox.moe/0aulsg.png)


</details>


<details>
<summary> HSV skin recolors !!!!!!!  </summary>

- lets you make custom skins base off HSV values !!! just load in with the skin you want to make an edit of ,..,. run "recolor_skin (hue) (saturation) (value)" and once it looks nice do "create_skin (skin name)" then itll appear in lobby the next game start !!! 
- this will likely end up becoming its own mod but for nows limited to bnr land ,.,. consider it technically a little in beta since it can make load times a slights bit longer .,,.,.,
- works with modded characters too !!!! showcase exmaples below ,.,. 

using orbit's [surivorsreturn](https://thunderstore.io/package/Orbital/SurvivorsReturn/) skinpack ,.,. ``Infamy,Bandit2Body,320,-10,5,ralsei bandit``

![](https://files.catbox.moe/exm45b.png)

``SkinNemCommandoDefault,NemCommandoBody,160,90,0,greenemmando``

![](https://files.catbox.moe/6axg8k.png)

``skinDroneTechDef,DroneTechBody,170,-30,0,gemporator``

![](https://files.catbox.moe/nuczzj.png)

``skinLoaderAltSolus,LoaderBody,200,-20,3,evil2``

![](https://files.catbox.moe/be9pxp.png)

basically tutorial on how to use ,..,

![](https://files.catbox.moe/yvdx4l.gif)

![](https://files.catbox.moe/z3gwae.png)

</details>

<details>
<summary> ui edits !!  </summary>

- (disabled by default since some stuff is a little weird with it ,.,.) customize button colors .,.,.
- shrink money to be how it used to pre SOTV (i miss you ,,,..,,..

![](https://files.catbox.moe/4cse35.png)

</details>

<details>
<summary> color edits,. .,  </summary>

- allows you to change any color in the games color catalog ,. ., notably allows you to change interact color .,.,,.

![](https://files.catbox.moe/zowfuv.png)

</details>

<details>
<summary> post processing,. .,  </summary>

- allows you to modify post processing of any stage .,.,,. its uhh .,,. its a little complicated but i explain it in video here https://youtu.be/rZ7xW9sVDIQ ,.,. 
- example of like .,. ambient occlusion being added to titanic plains .,,.

![](https://files.catbox.moe/hqmudm.png)

![](https://files.catbox.moe/0z2390.png)

</details>

<details>
<summary> team health color,. .,  </summary>

- lets you cahnge the color of teams ., like making things on the monster team have pink health bars or something .,. or changing your own to be pink ,., i like pink if you couldnt tell ,.

![](https://files.catbox.moe/sxxcpj.png)


</details>

<details>
<summary> ukulele pronouns,. .,  </summary>

- changes ukulele to use the current survivors pronouns instead of "he" ,.., forwardport from ss1 ,. goes off survivor ending text so if one doesnt use " she " " it " or " they " might not work right.,,. comes with config to override pronouns based off characterbody too ,.,..,
- comes with config to override looking glass too ,. ,.

![](https://files.catbox.moe/wvon6i.png)

![](https://files.catbox.moe/lxlhzn.png)
</details>

<details>
<summary> who did damage  </summary>

- sends a chat message with who did the most damage to whatever the current boss is in multiplayer ,.,.. also adds a little crown to the scoreboard for whoever did the most .,.,

![](https://files.catbox.moe/lnqcpz.png)

</details>

<details>
<summary> halcyonite shrines  !!  </summary>

- turn green portal into blue once the teleporter event is complete !!!! (im sorry i dont want to go on colossus' wild ride !!!

</details>

<details>
<summary> drifter !!!  !!  </summary>

- set scrapcube deployable limit ,..,

</details>

<details>
<summary> malachites !!!  !!  </summary>

- haves them spawn urchins every 12 seconds !! wisterawolf askeds for this one but merging into here so its on thunderstores ,.,..,

</details>

<details>
<summary> drone visibility !!!  !!  </summary>

- older ands or more janky version of [drone repair beacon](https://thunderstore.io/package/icebro/DroneRepairBeacon/) !!!! but aesthetics differents ,,..,.,, addeds by request of kismet o ndiscord !!!
- code is a bit silly so money will also be visible for however long the indicator is but donts worry about it <333

![](https://files.catbox.moe/cn0sil.png)

![](https://files.catbox.moe/ex0e5h.png)
</details>

<details>
<summary> ping recolors !!!  !!  </summary>

- recolor pings !!! colors in screenshots are different from default config; just all set to regular ping ,..,

![](https://files.catbox.moe/okvzsw.png)

![](https://files.catbox.moe/e7hyb3.png)

![](https://files.catbox.moe/vkmoyt.png)


</details>

### mod edits ,..,.,
<details>
<summary> cooler eclipse edits!!  </summary>

- [mod link ,..,](https://thunderstore.io/package/Nuxlar/CoolerEclipse/)
 - adds config chance to eclipses rather than just 50-50 .,.,
 - adds a 'pink' variant of eclipse ,.,,,
 - adds a stage blacklist and whitelist ,,.,.,

![](https://files.catbox.moe/4b7ov1.png)

</details>

<details>
<summary> golden coast plus revived edits !!  </summary>

- [mod link ,..,](https://thunderstore.io/package/TechDebtCollector/GoldenCoastPlus/)
 - skip buff given when you beat (i didnt like sorr y,..,.,,.,.

</details>

<details>
<summary> starstorm !!  </summary>

- [mod link ,..,](https://thunderstore.io/package/TeamMoonstorm/Starstorm2/)
- give icetool chance to apply a debuff on hit that decreases enemy movespeed by 5% per stack .,,. 5 stack causes the enemy to freeze (eg. artificer wall( !!! kinds of broken tbh because of the execute but its okay <33 ,.,.,.,

</details>

<details>
<summary> inferno !!  </summary>

- [mod link ,..,](https://thunderstore.io/package/prodzpod/Inferno/)
 - remove beetles not being able to be stunned !!! we hate beetle s !!!!!!!!!!!!!!

</details>

<details>
<summary> allynames !!  </summary>

- [mod link ,.,.](https://thunderstore.io/c/riskofrain2/p/SwagWizards/AllyNames/)
 - add custom body name config !!!! add any body names you want for thems to be renamed .,,.,. comes with oddbreads pr for allyname's alloyed collective pr by them !!! go say thank you !!!!!

![](https://files.catbox.moe/g5hbx6.png)
</details>

<details>
<summary> skillsmas !!  </summary>

- [mod link ,.,.](https://thunderstore.io/c/riskofrain2/p/FortunesTeam/Skillsmas/)
- rage edit .,,., makes mercenary's zandatsu recharge it's skill cooldown if it kills an enemy !!!! it uses the bandit sound and it made me weirdly mad that it didnt ,.,.

</details>

<details>
<summary> enemies return !!  </summary>

- [mod link ,.,.](https://thunderstore.io/c/riskofrain2/p/Risky_Sleeps/EnemiesReturns/)
- adds a pink variant of commandos judgement skin !!! pink halo included .,,. you can change the color in the config to whatevers you want !! 

![](https://files.catbox.moe/yx3opp.png)

</details>



### items ,.,.
|![carving kit](https://raw.githubusercontent.com/gamrtiem/code-mods/refs/heads/main/butterscotchnroses/assetbundle/carvingkit.png) | **Carving Kit** | After interacting with a ``Shrine of the Woods``, gain a piece of``bark`` that drops after standing still for ``2`` seconds, healing for ``6%`` ``(+4% per stack)`` of your health every second to all allies within ``7m`` ``(+4m per stack)``. Guarantee a ``Shrine of the Woods`` spawn.
|:-|-|------|

![](https://files.catbox.moe/u8kke4.png)

special ultra thanks you to acanthi for modeling and makings carving kit icon real !!!!!!!!!!!!!!!!!!!!!!everyones say we love you canthi ,.,.
